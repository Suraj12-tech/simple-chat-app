package project.ai_chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiChatApplication.class, args);
	}

}
