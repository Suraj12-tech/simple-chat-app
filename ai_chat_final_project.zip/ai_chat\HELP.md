# Getting Started

### Local Gemini Setup

Backend Gemini API key ko `GEMINI_API_KEY` se read karta hai.

Option 1: `ai_chat/.env.example` ko `ai_chat/.env` me copy karke apni key set karein:

```properties
GEMINI_API_KEY=your_real_key_here
GEMINI_MODEL=gemini-2.5-flash
```

Option 2: PowerShell session me env var set karke backend run karein:

```powershell
$env:GEMINI_API_KEY="your_real_key_here"
.\mvnw.cmd spring-boot:run
```

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/3.5.15/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.5.15/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/3.5.15/reference/web/servlet.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.
